# RestauranteApp

Aplicación de escritorio para toma de pedidos en restaurante.
Proyecto básico con estructuras de datos. - Java 

https://www.youtube.com/watch?v=7_YWRGVXV1w&t=4s 

To execute use ->
User: Administrador
Password: admin
