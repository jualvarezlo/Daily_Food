package Uml;

public class Cocina {

    private Boolean disponibilidadP;

    private String nomCocinero;

    private Boolean addIgredientes;

    public void platosPerdidos() {
    }
}
